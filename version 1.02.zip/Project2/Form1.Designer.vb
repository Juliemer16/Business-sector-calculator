﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As ComponentModel.ComponentResourceManager = New ComponentModel.ComponentResourceManager(GetType(Form1))
        txtRetailPrice = New TextBox()
        txtSRP = New TextBox()
        Label1 = New Label()
        Label2 = New Label()
        btnCalculate = New Button()
        btnDownpayment = New Button()
        Label3 = New Label()
        Label4 = New Label()
        Label5 = New Label()
        Label6 = New Label()
        txt3months = New TextBox()
        txt6months = New TextBox()
        txt9Months = New TextBox()
        txt12Months = New TextBox()
        txtDownpayment = New TextBox()
        lblFinalPrice = New TextBox()
        btnMonthly = New Button()
        txtRange = New TextBox()
        lblDownpayment = New TextBox()
        Label7 = New Label()
        Label8 = New Label()
        Label9 = New Label()
        Label10 = New Label()
        SuspendLayout()
        ' 
        ' txtRetailPrice
        ' 
        txtRetailPrice.BorderStyle = BorderStyle.FixedSingle
        txtRetailPrice.Font = New Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point)
        txtRetailPrice.Location = New Point(71, 173)
        txtRetailPrice.Multiline = True
        txtRetailPrice.Name = "txtRetailPrice"
        txtRetailPrice.Size = New Size(144, 33)
        txtRetailPrice.TabIndex = 0
        txtRetailPrice.TextAlign = HorizontalAlignment.Center
        ' 
        ' txtSRP
        ' 
        txtSRP.BorderStyle = BorderStyle.FixedSingle
        txtSRP.Font = New Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point)
        txtSRP.Location = New Point(599, 171)
        txtSRP.Multiline = True
        txtSRP.Name = "txtSRP"
        txtSRP.Size = New Size(154, 33)
        txtSRP.TabIndex = 1
        txtSRP.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.White
        Label1.Font = New Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.Location = New Point(81, 87)
        Label1.Name = "Label1"
        Label1.Size = New Size(125, 50)
        Label1.TabIndex = 6
        Label1.Text = "Commission " & vbCrLf & "  Base Price"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.White
        Label2.Font = New Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point)
        Label2.Location = New Point(599, 87)
        Label2.Name = "Label2"
        Label2.Size = New Size(143, 50)
        Label2.TabIndex = 7
        Label2.Text = "        Client" & vbCrLf & "Downpayment"
        ' 
        ' btnCalculate
        ' 
        btnCalculate.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        btnCalculate.Location = New Point(71, 460)
        btnCalculate.Name = "btnCalculate"
        btnCalculate.Size = New Size(144, 52)
        btnCalculate.TabIndex = 8
        btnCalculate.Text = "Calculate CBP"
        btnCalculate.UseVisualStyleBackColor = True
        ' 
        ' btnDownpayment
        ' 
        btnDownpayment.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        btnDownpayment.Location = New Point(599, 460)
        btnDownpayment.Name = "btnDownpayment"
        btnDownpayment.Size = New Size(154, 52)
        btnDownpayment.TabIndex = 10
        btnDownpayment.Text = "Calculate" & vbCrLf & "DP"
        btnDownpayment.UseVisualStyleBackColor = True
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.White
        Label3.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.Location = New Point(370, 87)
        Label3.Name = "Label3"
        Label3.Size = New Size(81, 21)
        Label3.TabIndex = 11
        Label3.Text = "3 Months"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.White
        Label4.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Label4.Location = New Point(370, 176)
        Label4.Name = "Label4"
        Label4.Size = New Size(81, 21)
        Label4.TabIndex = 12
        Label4.Text = "6 Months"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.BackColor = Color.White
        Label5.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Label5.Location = New Point(370, 267)
        Label5.Name = "Label5"
        Label5.Size = New Size(81, 21)
        Label5.TabIndex = 13
        Label5.Text = "9 Months"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.BackColor = Color.White
        Label6.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Label6.Location = New Point(370, 356)
        Label6.Name = "Label6"
        Label6.Size = New Size(90, 21)
        Label6.TabIndex = 14
        Label6.Text = "12 Months"
        ' 
        ' txt3months
        ' 
        txt3months.BackColor = SystemColors.Info
        txt3months.BorderStyle = BorderStyle.FixedSingle
        txt3months.Enabled = False
        txt3months.Font = New Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point)
        txt3months.ImeMode = ImeMode.NoControl
        txt3months.Location = New Point(317, 124)
        txt3months.Multiline = True
        txt3months.Name = "txt3months"
        txt3months.ReadOnly = True
        txt3months.Size = New Size(181, 33)
        txt3months.TabIndex = 15
        txt3months.TextAlign = HorizontalAlignment.Center
        ' 
        ' txt6months
        ' 
        txt6months.BackColor = SystemColors.Info
        txt6months.BorderStyle = BorderStyle.FixedSingle
        txt6months.Enabled = False
        txt6months.Font = New Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point)
        txt6months.Location = New Point(317, 214)
        txt6months.Multiline = True
        txt6months.Name = "txt6months"
        txt6months.ReadOnly = True
        txt6months.Size = New Size(184, 33)
        txt6months.TabIndex = 16
        txt6months.TextAlign = HorizontalAlignment.Center
        ' 
        ' txt9Months
        ' 
        txt9Months.BackColor = SystemColors.Info
        txt9Months.BorderStyle = BorderStyle.FixedSingle
        txt9Months.Enabled = False
        txt9Months.Font = New Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point)
        txt9Months.Location = New Point(320, 304)
        txt9Months.Multiline = True
        txt9Months.Name = "txt9Months"
        txt9Months.ReadOnly = True
        txt9Months.Size = New Size(181, 33)
        txt9Months.TabIndex = 17
        txt9Months.TextAlign = HorizontalAlignment.Center
        ' 
        ' txt12Months
        ' 
        txt12Months.BackColor = SystemColors.Info
        txt12Months.BorderStyle = BorderStyle.FixedSingle
        txt12Months.Enabled = False
        txt12Months.Font = New Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point)
        txt12Months.Location = New Point(317, 393)
        txt12Months.Multiline = True
        txt12Months.Name = "txt12Months"
        txt12Months.ReadOnly = True
        txt12Months.Size = New Size(184, 33)
        txt12Months.TabIndex = 18
        txt12Months.TextAlign = HorizontalAlignment.Center
        ' 
        ' txtDownpayment
        ' 
        txtDownpayment.BorderStyle = BorderStyle.FixedSingle
        txtDownpayment.Font = New Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point)
        txtDownpayment.Location = New Point(71, 262)
        txtDownpayment.Multiline = True
        txtDownpayment.Name = "txtDownpayment"
        txtDownpayment.Size = New Size(144, 33)
        txtDownpayment.TabIndex = 19
        txtDownpayment.TextAlign = HorizontalAlignment.Center
        ' 
        ' lblFinalPrice
        ' 
        lblFinalPrice.BorderStyle = BorderStyle.FixedSingle
        lblFinalPrice.Font = New Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point)
        lblFinalPrice.Location = New Point(71, 364)
        lblFinalPrice.Multiline = True
        lblFinalPrice.Name = "lblFinalPrice"
        lblFinalPrice.Size = New Size(144, 33)
        lblFinalPrice.TabIndex = 20
        lblFinalPrice.TextAlign = HorizontalAlignment.Center
        ' 
        ' btnMonthly
        ' 
        btnMonthly.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        btnMonthly.Location = New Point(335, 460)
        btnMonthly.Name = "btnMonthly"
        btnMonthly.Size = New Size(154, 52)
        btnMonthly.TabIndex = 21
        btnMonthly.Text = "Calculate " & vbCrLf & "Monthly"
        btnMonthly.UseVisualStyleBackColor = True
        ' 
        ' txtRange
        ' 
        txtRange.BackColor = SystemColors.Info
        txtRange.BorderStyle = BorderStyle.FixedSingle
        txtRange.Font = New Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point)
        txtRange.Location = New Point(599, 267)
        txtRange.Multiline = True
        txtRange.Name = "txtRange"
        txtRange.Size = New Size(154, 33)
        txtRange.TabIndex = 22
        txtRange.Text = "."
        txtRange.TextAlign = HorizontalAlignment.Center
        ' 
        ' lblDownpayment
        ' 
        lblDownpayment.BackColor = SystemColors.Info
        lblDownpayment.BorderStyle = BorderStyle.FixedSingle
        lblDownpayment.Font = New Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point)
        lblDownpayment.Location = New Point(599, 364)
        lblDownpayment.Multiline = True
        lblDownpayment.Name = "lblDownpayment"
        lblDownpayment.Size = New Size(154, 33)
        lblDownpayment.TabIndex = 23
        lblDownpayment.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Label7.Location = New Point(125, 209)
        Label7.Name = "Label7"
        Label7.Size = New Size(39, 21)
        Label7.TabIndex = 24
        Label7.Text = "SRP"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Label8.Location = New Point(81, 298)
        Label8.Name = "Label8"
        Label8.Size = New Size(123, 21)
        Label8.TabIndex = 25
        Label8.Text = "Downpayment"
        ' 
        ' Label9
        ' 
        Label9.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Label9.Location = New Point(71, 400)
        Label9.Name = "Label9"
        Label9.Size = New Size(144, 46)
        Label9.TabIndex = 26
        Label9.Text = "Commission Base Price"
        Label9.TextAlign = ContentAlignment.TopCenter
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Label10.Location = New Point(661, 209)
        Label10.Name = "Label10"
        Label10.Size = New Size(39, 21)
        Label10.TabIndex = 27
        Label10.Text = "SRP"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.Menu
        BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), Image)
        BackgroundImageLayout = ImageLayout.Stretch
        ClientSize = New Size(815, 561)
        Controls.Add(Label10)
        Controls.Add(Label9)
        Controls.Add(Label8)
        Controls.Add(Label7)
        Controls.Add(lblDownpayment)
        Controls.Add(txtRange)
        Controls.Add(btnMonthly)
        Controls.Add(lblFinalPrice)
        Controls.Add(txtDownpayment)
        Controls.Add(txt12Months)
        Controls.Add(txt9Months)
        Controls.Add(txt6months)
        Controls.Add(txt3months)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(btnDownpayment)
        Controls.Add(btnCalculate)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(txtSRP)
        Controls.Add(txtRetailPrice)
        DoubleBuffered = True
        Font = New Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point)
        FormBorderStyle = FormBorderStyle.FixedSingle
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        Name = "Form1"
        Text = "Caparal Installment Calculator"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents txtRetailPrice As TextBox
    Friend WithEvents txtSRP As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnDownpayment As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txt3months As TextBox
    Friend WithEvents txt6months As TextBox
    Friend WithEvents txt9Months As TextBox
    Friend WithEvents txt12Months As TextBox
    Friend WithEvents txtDownpayment As TextBox
    Friend WithEvents lblFinalPrice As TextBox
    Friend WithEvents btnMonthly As Button
    Friend WithEvents txtRange As TextBox
    Friend WithEvents lblDownpayment As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
End Class
