﻿Imports System.Globalization

Public Class Form1

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click

        ' parse input values from textboxes

        Dim retailPrice As Double = Double.Parse(txtRetailPrice.Text)

        Dim downPayment As Double = Double.Parse(txtDownpayment.Text)

        ' calculate the price

        Dim finalPrice As Double = (retailPrice - downPayment) * 1.08 + 100


        ' Create a New CultureInfo Object For the desired culture

        Dim culture As New System.Globalization.CultureInfo("en-PH")

        ' Set the currency symbol To "PHP"

        culture.NumberFormat.CurrencySymbol = (lblFinalPrice.Text)

        ' Set the current culture To the New culture

        Threading.Thread.CurrentThread.CurrentCulture = culture

        ' display the result

        lblFinalPrice.Text = finalPrice.ToString("C2")


    End Sub

    ' get.parse downpayment value & CBP value = show.result in 4 quarter of the year using calculate button.

    Private Sub btnMonthly_Click(sender As Object, e As EventArgs) Handles btnMonthly.Click


        Dim price As Double = CDbl(lblFinalPrice.Text)


        Dim price3Months As Double = price * 1.25 + 300 / 3

        Dim price6Months As Double = price * 1.3 + 600 / 6

        Dim price9Months As Double = price * 1.45 + 900 / 9

        Dim price12Months As Double = price * 1.6 + 1200 / 12

        txt3months.Text = price3Months.ToString("F2")

        txt6months.Text = price6Months.ToString("F2")

        txt9Months.Text = price9Months.ToString("F2")

        txt12Months.Text = price12Months.ToString("F2")


    End Sub

    Private Sub btnDownpayment_Click(sender As Object, e As EventArgs) Handles btnDownpayment.Click


        'parse the value of each textboxes

        Dim txtSRP As Double

        'calculate the downpayment
        Dim downpaymentPercentage As Double = 0


        Dim downpaymentAmount As Double = 0

        If txtSRP >= 10999 Then
            downpaymentPercentage = 0.25
        ElseIf txtSRP >= 19999 Then
            downpaymentPercentage = 0.3
        ElseIf txtSRP >= 29999 Then
            downpaymentPercentage = 0.35
        ElseIf txtSRP >= 39999 Then
            downpaymentPercentage = 0.4
        ElseIf txtSRP >= 49999 Then
            downpaymentPercentage = 0.45
        Else
            downpaymentPercentage = 0.5
        End If


        downpaymentAmount = (txtSRP * downpaymentPercentage + 200)

        lblDownpayment.Text = downpaymentAmount.ToString()

        Dim txtRange As Activator

        Activator.Equals = (txtSRP * txtRange + 200 = txtDownpayment.Text)



    End Sub



End Class
